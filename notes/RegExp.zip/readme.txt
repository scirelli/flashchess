RegExp object for Flash5 ActionScript Ver1.02
   Author: Pavils Jurjans
   Email : pavils@mailbox.riga.lv
   Default source for this file can be found at http://www.jurjans.lv/flash/RegExp.html
---------------------------------------------------------------------------------------------------
This class is provided for flash community for free with a kind request 
to keep the copyright lines in AS file untouched. However, debugging and 
development of class takes much time limiting my opportunities to earn 
some income on other projects. To overcome this, I have set up an account 
with PayPal (http://www.paypal.com). Please, if you find my work valuable,
especially if you use it in commercial projects, make a donation 
to pavils@mailbox.riga.lv of amount you feel is right. Please provide your
E-mail address upon payment submission so I can enlist you in my upgrade newslist.
---------------------------------------------------------------------------------------------------

The contents of this pagkage:

RegExp.as	- The ActionScript include file. Write << #include "RegExp.as" >> in your Flash project to use it
RegExp.fla	- The Flash5 source of testing platform
RegExp.html	- HTML document for testing platform hosting.
RegExp.swf	- Testing platform movie
RegExp.xml	- The AS panel extension for Flash MX users. Enables to include the RegExp object properties and methods in the ActionScippt panel, enables auto-completion and syntax color-coding. See Configuration_ReadMe.htm for installation instructions.
Configuration_ReadMe.htm - Flash MX custom configuration readme file

